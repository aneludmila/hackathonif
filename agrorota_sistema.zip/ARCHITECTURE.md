# Arquitetura - AgroRota Inteligente

## Visão Geral

A plataforma AgroRota Inteligente é uma aplicação web full-stack que monitora a trafegabilidade de estradas vicinais em Ariquemes/RO, fornecendo alertas preditivos, relatos comunitários e um score de condição chamado **AgroScore**.

## Estrutura de Dados

### Tabelas Principais

#### `roads` - Estradas Vicinais
- `id` (int, PK)
- `name` (varchar) - Nome da linha (ex: C-70, B-40)
- `description` (text)
- `totalKm` (decimal) - Extensão total em km
- `coordinates` (json) - Array de pontos [lat, lng] para desenho no mapa
- `createdAt` (timestamp)
- `updatedAt` (timestamp)

#### `reports` - Relatos Comunitários
- `id` (int, PK)
- `roadId` (int, FK) - Referência à estrada
- `userId` (int, FK) - Quem registrou
- `latitude` (decimal)
- `longitude` (decimal)
- `reportType` (enum) - "pothole", "flooding", "mud", "other"
- `description` (text)
- `photoUrl` (varchar) - URL da foto no S3
- `severity` (enum) - "low", "medium", "high"
- `status` (enum) - "open", "acknowledged", "resolved"
- `createdAt` (timestamp)
- `updatedAt` (timestamp)

#### `alerts` - Alertas Preditivos
- `id` (int, PK)
- `roadId` (int, FK)
- `riskLevel` (enum) - "low", "medium", "high"
- `reason` (text) - Motivo do alerta (ex: "Previsão de chuva intensa")
- `predictedDate` (date)
- `createdAt` (timestamp)
- `expiresAt` (timestamp)

#### `users` - Usuários (já existe no template)
- `id` (int, PK)
- `openId` (varchar, unique)
- `name` (text)
- `email` (varchar)
- `role` (enum) - "user", "admin" (será estendido para "producer", "manager")
- `userType` (enum) - "producer", "manager", "viewer" (novo campo)
- `createdAt` (timestamp)
- `updatedAt` (timestamp)

### Tabelas Auxiliares

#### `agro_scores` - Histórico de AgroScores
- `id` (int, PK)
- `roadId` (int, FK)
- `score` (decimal) - 0-100
- `calculatedAt` (timestamp)
- `factors` (json) - Detalhes do cálculo

## Lógica de Negócio

### AgroScore

O AgroScore é um indicador de 0 a 100 que representa a condição de trafegabilidade de uma estrada, calculado a partir de:

1. **Relatos Recentes (60%):** Peso maior para relatos dos últimos 7 dias
   - Cada relato "high" reduz 15 pontos
   - Cada relato "medium" reduz 8 pontos
   - Cada relato "low" reduz 3 pontos
   - Relatos resolvidos têm peso reduzido

2. **Dados Climáticos (30%):** Previsão de chuva e histórico
   - Sem chuva: +0 pontos
   - Chuva leve: -5 pontos
   - Chuva moderada: -15 pontos
   - Chuva intensa: -30 pontos

3. **Tendência Histórica (10%):** Padrão de degradação
   - Se AgroScore vinha caindo: -5 pontos
   - Se AgroScore vinha estável: +0 pontos
   - Se AgroScore vinha melhorando: +5 pontos

**Fórmula:**
```
AgroScore = 100 - (relatos_impacto * 0.6) - (clima_impacto * 0.3) - (tendencia_impacto * 0.1)
AgroScore = max(0, min(100, AgroScore))
```

### Status de Trafegabilidade

- **Verde (Trafegável):** AgroScore >= 70
- **Amarelo (Atenção):** 40 <= AgroScore < 70
- **Vermelho (Intransitável):** AgroScore < 40

## Fluxos Principais

### 1. Registro de Relato (Usuário Autenticado)
1. Usuário clica em "Novo Relato"
2. Sistema obtém geolocalização automática
3. Usuário seleciona tipo de ocorrência e anexa foto
4. Foto é enviada para S3 via `storagePut()`
5. Relato é salvo no banco com `reports.photoUrl`
6. AgroScore da estrada é recalculado
7. Se novo AgroScore < 40, alerta é gerado automaticamente

### 2. Consulta Pública de Trafegabilidade
1. Usuário acessa `/roads/public`
2. Busca por nome de linha (ex: "C-70")
3. Sistema retorna AgroScore, status e últimos relatos
4. Sem necessidade de autenticação

### 3. Dashboard do Gestor Público
1. Gestor faz login com perfil "manager"
2. Vê dashboard com:
   - AgroScore agregado de todas as estradas
   - Alertas ativos
   - Total de km monitorados
   - Mapa com todos os relatos
3. Pode filtrar por status e data

## Integração com APIs Externas

### Google Maps
- Renderizar mapa interativo
- Geocodificação de relatos
- Cálculo de distâncias

### Dados Climáticos (Mock para MVP)
- Previsão de chuva por localização
- Histórico de precipitação
- Será integrado com API real (INMET, OpenWeatherMap) em versão futura

## Segurança e Permissões

### Perfis de Usuário
- **Produtor (producer):** Pode registrar relatos, ver mapa público, consultar trafegabilidade
- **Gestor Público (manager):** Acesso total ao dashboard, pode resolver relatos, gerar relatórios
- **Visualizador (viewer):** Acesso somente leitura ao mapa e relatos

### Autenticação
- Manus OAuth para login
- Session cookies com JWT
- Proteção de procedures com `protectedProcedure`

## Stack Tecnológico

- **Frontend:** React 19 + Tailwind 4 + shadcn/ui
- **Backend:** Express 4 + tRPC 11
- **Banco de Dados:** MySQL (TiDB)
- **Armazenamento:** S3 (Manus Storage)
- **Mapas:** Google Maps API (via proxy Manus)
- **Autenticação:** Manus OAuth

## Roadmap Futuro

1. Integração com dados climáticos reais (INMET)
2. Notificações push para alertas críticos
3. Relatórios em PDF para gestores
4. API pública para integração com sistemas municipais
5. Mobile app nativa
6. Integração com sistemas de manutenção viária
