# AgroRota Inteligente - Guia de Uso

## Bem-vindo à Plataforma de Monitoramento de Estradas Rurais

**AgroRota Inteligente** é uma plataforma de monitoramento preditivo de trafegabilidade de estradas vicinais desenvolvida para Ariquemes, RO. A plataforma conecta produtores rurais, motoristas e gestores públicos através de relatos comunitários, alertas preditivos e transparência de dados.

---

## 🚀 Como Começar

### 1. Acessar a Plataforma
- Visite a página inicial da AgroRota Inteligente
- Clique em **"Entrar"** para fazer login com sua conta Manus

### 2. Selecionar seu Perfil
Após o login, você será solicitado a escolher um perfil:

#### **Produtor Rural** 🌾
- Registre relatos sobre condições das estradas
- Acompanhe o status de trafegabilidade em tempo real
- Receba alertas sobre riscos de intransitabilidade
- Histórico de seus relatos

#### **Gestor Público** 🛡️
- Gerencie relatos da comunidade
- Defina alertas preditivos
- Planeje manutenção preventiva
- Visualize dados agregados de trafegabilidade

#### **Visualizador** 👥
- Consulte dados de trafegabilidade
- Acesse histórico de relatos
- Visualize alertas ativos
- Sem permissão de criar relatos

---

## 📍 Funcionalidades Principais

### Dashboard
O painel principal exibe:
- **AgroScore Agregado**: Score de condição geral das estradas (0-100)
- **Alertas Ativos**: Número de alertas preditivos em vigor
- **Total de km Monitorados**: Extensão das estradas vicinais sob monitoramento
- **Últimos Relatos**: Relatos recentes da comunidade

### Mapa Interativo
- Visualize todas as estradas vicinais de Ariquemes
- Marcadores de pontos críticos e relatos
- Legenda de cores:
  - 🟢 **Verde**: Trafegável (AgroScore ≥ 70)
  - 🟡 **Amarelo**: Atenção (40 ≤ AgroScore < 70)
  - 🔴 **Vermelho**: Intransitável (AgroScore < 40)

### Registrar Relatos (Produtores)
1. Acesse a página **"Relatos"**
2. Preencha o formulário com:
   - **Linha/Estrada**: Selecione a estrada afetada
   - **Tipo de Ocorrência**: Atolamento, buraco, alagamento, etc.
   - **Localização**: Geolocalização automática (ou manual)
   - **Descrição**: Detalhes da ocorrência
   - **Foto**: Anexe uma foto da situação
   - **Severidade**: Baixa, média ou alta
3. Clique em **"Enviar Relato"**

### Consultar Trafegabilidade (Público)
- Acesse **"Consultar Trafegabilidade"** (sem necessidade de login)
- Busque por nome da linha (ex: C-70, B-40)
- Visualize o status e o AgroScore de cada estrada
- Veja o histórico de relatos

### Sobre o Projeto
- Conheça o contexto e impacto das estradas rurais
- Dados reais de Ariquemes (IDARON, Prefeitura, CNM)
- Entenda a solução e o AgroScore

---

## 📊 O AgroScore

O **AgroScore** é o indicador de condição de cada estrada, calculado através de:

1. **Relatos Comunitários** (40% do peso)
   - Frequência e severidade dos relatos
   - Tendência (melhora ou piora)

2. **Dados Climáticos** (40% do peso)
   - Previsão de chuva
   - Histórico de precipitação

3. **Tendência Temporal** (20% do peso)
   - Evolução do score ao longo do tempo
   - Sazonalidade

**Escala:**
- **70-100**: Trafegável ✅
- **40-69**: Atenção ⚠️
- **0-39**: Intransitável ❌

---

## 🔐 Segurança e Privacidade

- Autenticação segura via Manus OAuth
- Dados pessoais protegidos
- Relatos vinculados ao seu perfil
- Permissões diferenciadas por tipo de usuário

---

## 📱 Compatibilidade

- **Desktop**: Chrome, Firefox, Safari, Edge
- **Mobile**: iOS (Safari), Android (Chrome)
- **Responsivo**: Otimizado para telas de 375px até 1920px

---

## ❓ Dúvidas Frequentes

### Como meu relato ajuda?
Seus relatos alimentam o AgroScore, que ajuda gestores públicos a priorizar manutenção preventiva e produtores a planejar rotas.

### Meu relato aparecerá no mapa?
Sim! Após aprovação, seu relato aparecerá no mapa interativo com localização, foto e descrição.

### Posso editar meu relato?
Sim, você pode editar relatos pendentes. Após aprovação, entre em contato com gestores para alterações.

### Como funciona a previsão de alertas?
O sistema integra dados de previsão de chuva com histórico de ocorrências para prever riscos de intransitabilidade.

---

## 📞 Suporte

Para dúvidas ou problemas:
- Consulte a página **"Sobre o Projeto"**
- Verifique as fontes de dados (IDARON, Prefeitura, CNM)
- Entre em contato com o gestor da plataforma

---

## 🎯 Dados Reais de Ariquemes

### Rebanho (IDARON - Julho 2020)
- **Bovinos**: 459.435 cabeças
- **Bubalinos**: 516 cabeças
- **Caprinos**: 408 cabeças
- **Ovinos**: 2.596 cabeças
- **Suínos**: 3.168 cabeças

### Infraestrutura Viária
- **Estradas Vicinais Monitoradas**: 8 principais linhas
- **Extensão Total**: ~282 km
- **Cobertura**: Ligação entre propriedades rurais e centros de processamento

### Impacto Econômico
- Perdas anuais por intransitabilidade: Estimadas em milhões de reais
- Custo de manutenção emergencial: 3-5x maior que preventiva
- Investimento necessário (CNM): R$ 12,6 bilhões para elevar padrão

---

**Desenvolvido com ❤️ para Ariquemes, RO**

*Última atualização: Junho 2026*
