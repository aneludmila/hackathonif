import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Leaf, Users, Shield } from "lucide-react";
import { toast } from "sonner";

interface ProfileSelectionModalProps {
  isOpen: boolean;
  onClose: (userType: string) => void;
}

export function ProfileSelectionModal({ isOpen, onClose }: ProfileSelectionModalProps) {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const setProfileMutation = trpc.userProfile.set.useMutation({
    onSuccess: () => {
      toast.success("Perfil configurado com sucesso!");
      if (selectedType) {
        onClose(selectedType);
      }
    },
    onError: (error) => {
      toast.error(`Erro ao configurar perfil: ${error.message}`);
    },
  });

  const handleConfirm = async () => {
    if (!selectedType) {
      toast.error("Selecione um perfil");
      return;
    }

    setIsSubmitting(true);
    try {
      await setProfileMutation.mutateAsync({
        userType: selectedType as "producer" | "manager" | "viewer",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="p-8 max-w-2xl w-full mx-4">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Selecione seu Perfil</h2>
          <p className="text-gray-600">
            Escolha o tipo de perfil que melhor descreve sua função na plataforma
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {/* Produtor */}
          <div
            onClick={() => setSelectedType("producer")}
            className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
              selectedType === "producer"
                ? "border-green-600 bg-green-50"
                : "border-gray-200 hover:border-green-300"
            }`}
          >
            <Leaf className="w-8 h-8 text-green-600 mb-3" />
            <h3 className="font-bold text-lg mb-2">Produtor Rural</h3>
            <p className="text-sm text-gray-600">
              Registre relatos sobre condições das estradas e acompanhe o status de trafegabilidade
            </p>
          </div>

          {/* Gestor */}
          <div
            onClick={() => setSelectedType("manager")}
            className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
              selectedType === "manager"
                ? "border-blue-600 bg-blue-50"
                : "border-gray-200 hover:border-blue-300"
            }`}
          >
            <Shield className="w-8 h-8 text-blue-600 mb-3" />
            <h3 className="font-bold text-lg mb-2">Gestor Público</h3>
            <p className="text-sm text-gray-600">
              Gerencie relatos, defina alertas e planeje manutenção preventiva
            </p>
          </div>

          {/* Visualizador */}
          <div
            onClick={() => setSelectedType("viewer")}
            className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
              selectedType === "viewer"
                ? "border-purple-600 bg-purple-50"
                : "border-gray-200 hover:border-purple-300"
            }`}
          >
            <Users className="w-8 h-8 text-purple-600 mb-3" />
            <h3 className="font-bold text-lg mb-2">Visualizador</h3>
            <p className="text-sm text-gray-600">
              Consulte dados de trafegabilidade e histórico de relatos
            </p>
          </div>
        </div>

        <div className="flex gap-4 justify-end">
          <Button
            variant="outline"
            onClick={() => onClose("")}
            disabled={isSubmitting}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!selectedType || isSubmitting}
          >
            {isSubmitting ? "Confirmando..." : "Confirmar"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
