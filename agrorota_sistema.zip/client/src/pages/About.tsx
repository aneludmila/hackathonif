import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Leaf, MapPin, TrendingUp, AlertTriangle } from "lucide-react";

export default function About() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota Inteligente</h1>
          </div>
          <nav className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation("/")}>
              Início
            </Button>
            <Button variant="ghost" onClick={() => setLocation("/roads")}>
              Consultar
            </Button>
            <Button onClick={() => setLocation("/")}>
              Entrar
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Hero */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Sobre o Projeto</h2>
          <p className="text-xl text-gray-600 max-w-3xl">
            AgroRota Inteligente é uma plataforma de monitoramento preditivo de trafegabilidade 
            de estradas vicinais desenvolvida para Ariquemes/RO, com foco em transparência de dados, 
            relatos comunitários e apoio à gestão pública.
          </p>
        </section>

        {/* Problema */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">O Problema</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-6">
              <AlertTriangle className="w-8 h-8 text-red-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Impacto na Produção</h4>
              <p className="text-gray-600">
                A falta de previsão e transparência sobre o estado das estradas vicinais prejudica 
                o escoamento de produtos perecíveis como leite e peixe, aumentando perdas econômicas 
                para produtores rurais.
              </p>
            </Card>

            <Card className="p-6">
              <MapPin className="w-8 h-8 text-orange-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Custos de Manutenção</h4>
              <p className="text-gray-600">
                Sem planejamento preventivo, os gestores públicos realizam reparos emergenciais 
                mais caros e ineficientes, desperdiçando recursos que poderiam ser melhor alocados.
              </p>
            </Card>
          </div>
        </section>

        {/* Dados Reais */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Dados Reais de Ariquemes</h3>
          
          {/* IDARON */}
          <Card className="p-6 mb-6 border-l-4 border-green-600">
            <h4 className="font-bold text-lg mb-4">📊 Rebanho em Ariquemes (IDARON - Julho 2020)</h4>
            <div className="grid md:grid-cols-5 gap-4">
              <div>
                <p className="text-sm text-gray-600">Bovinos</p>
                <p className="text-2xl font-bold text-green-600">459.435</p>
                <p className="text-xs text-gray-500">cabeças</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Bubalinos</p>
                <p className="text-2xl font-bold text-blue-600">516</p>
                <p className="text-xs text-gray-500">cabeças</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Caprinos</p>
                <p className="text-2xl font-bold text-purple-600">408</p>
                <p className="text-xs text-gray-500">cabeças</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Ovinos</p>
                <p className="text-2xl font-bold text-yellow-600">2.596</p>
                <p className="text-xs text-gray-500">cabeças</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Suínos</p>
                <p className="text-2xl font-bold text-red-600">3.168</p>
                <p className="text-xs text-gray-500">cabeças</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-4">
              <strong>Fonte:</strong> <a href="https://www.idaron.ro.gov.br" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Agência de Defesa Sanitária Agrosilvopastoril do Estado de Rondônia (IDARON)</a>
            </p>
          </Card>

          {/* Prefeitura de Ariquemes */}
          <Card className="p-6 mb-6 border-l-4 border-blue-600">
            <h4 className="font-bold text-lg mb-4">🛣️ Malha Viária Rural de Ariquemes</h4>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Total de Estradas Vicinais Monitoradas</p>
                <p className="text-3xl font-bold text-blue-600">2.500+ km</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Exemplo de Convênio FITHA (2019)</p>
                <p className="text-2xl font-bold text-blue-600">596,60 km</p>
                <p className="text-xs text-gray-500">de estradas rurais recuperadas em uma única etapa</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Principais Linhas</p>
                <p className="text-sm text-gray-700">
                  C-70, C-65, B-40, e outras que ligam fazendas aos centros de processamento
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-4">
              <strong>Fonte:</strong> <a href="https://www.ariquemes.ro.gov.br" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Secretaria Municipal de Obras e Serviços Públicos (SEMOSP) - Prefeitura de Ariquemes</a>
            </p>
          </Card>

          {/* CNM */}
          <Card className="p-6 border-l-4 border-purple-600">
            <h4 className="font-bold text-lg mb-4">🌍 Contexto Nacional de Estradas Vicinais</h4>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600">Total de Estradas Vicinais no Brasil</p>
                <p className="text-3xl font-bold text-purple-600">1,96 milhões km</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Estradas em Regiões Prioritárias</p>
                <p className="text-2xl font-bold text-purple-600">101 mil km</p>
                <p className="text-xs text-gray-500">que demandam investimento urgente</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Investimento Necessário</p>
                <p className="text-2xl font-bold text-purple-600">R$ 12,6 bilhões</p>
                <p className="text-xs text-gray-500">para elevar padrão de qualidade</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-4">
              <strong>Fonte:</strong> <a href="https://www.cnm.org.br" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Confederação Nacional de Municípios (CNM)</a> - Estudo de Estradas Vicinais (2025)
            </p>
          </Card>
        </section>

        {/* Solução */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Nossa Solução</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-6">
              <TrendingUp className="w-8 h-8 text-green-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">AgroScore</h4>
              <p className="text-gray-600">
                Score de 0-100 que indica a condição de trafegabilidade de cada estrada, 
                baseado em relatos comunitários, dados climáticos e tendência histórica.
              </p>
            </Card>

            <Card className="p-6">
              <AlertTriangle className="w-8 h-8 text-orange-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Alertas Preditivos</h4>
              <p className="text-gray-600">
                Notificações antecipadas baseadas em previsão de chuva e padrões históricos 
                de degradação, permitindo ação preventiva.
              </p>
            </Card>

            <Card className="p-6">
              <Leaf className="w-8 h-8 text-green-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Relatos Comunitários</h4>
              <p className="text-gray-600">
                Produtores e motoristas podem registrar ocorrências com fotos e localização, 
                criando um banco de dados colaborativo.
              </p>
            </Card>

            <Card className="p-6">
              <MapPin className="w-8 h-8 text-blue-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Transparência de Dados</h4>
              <p className="text-gray-600">
                Consulta pública de trafegabilidade sem necessidade de autenticação, 
                promovendo acesso igualitário à informação.
              </p>
            </Card>
          </div>
        </section>

        {/* Impacto Esperado */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Impacto Esperado</h3>
          <Card className="p-6 bg-gradient-to-r from-green-50 to-blue-50">
            <ul className="space-y-3">
              <li className="flex gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span className="text-gray-700">
                  <strong>Redução de perdas:</strong> Melhor planejamento de escoamento de produtos perecíveis
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span className="text-gray-700">
                  <strong>Eficiência de gastos:</strong> Manutenção preventiva mais barata que reparos emergenciais
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span className="text-gray-700">
                  <strong>Transparência:</strong> Comunidade informada sobre condições reais das vias
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span className="text-gray-700">
                  <strong>Engajamento:</strong> Produtores e motoristas como agentes de monitoramento
                </span>
              </li>
            </ul>
          </Card>
        </section>

        {/* CTA */}
        <section className="text-center mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Comece Agora</h3>
          <p className="text-gray-600 mb-6">
            Consulte o status das estradas ou registre relatos para ajudar a comunidade
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" onClick={() => setLocation("/roads")}>
              Consultar Trafegabilidade
            </Button>
            <Button size="lg" variant="outline" onClick={() => setLocation("/")}>
              Fazer Login
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-2">AgroRota Inteligente</h4>
              <p className="text-sm">
                Monitoramento preditivo de estradas rurais para Ariquemes/RO
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-2">Fontes</h4>
              <ul className="text-sm space-y-1">
                <li>• IDARON (Dados de Rebanho)</li>
                <li>• Prefeitura de Ariquemes</li>
                <li>• CNM (Confederação Nacional de Municípios)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Contato</h4>
              <p className="text-sm">
                Desenvolvido com foco em transparência e sustentabilidade rural
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center">
            <p>&copy; 2026 AgroRota Inteligente. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
