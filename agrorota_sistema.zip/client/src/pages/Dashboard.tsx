import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ProfileSelectionModal } from "@/components/ProfileSelectionModal";
import { Leaf, LogOut, MapPin, AlertTriangle, TrendingUp } from "lucide-react";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const { user, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [userType, setUserType] = useState<string | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);

  // Redirecionar se não autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  // Buscar tipo de usuário
  const { data: profile } = trpc.userProfile.get.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Buscar estradas com scores
  const { data: roads, isLoading: roadsLoading } = trpc.roads.listWithScores.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Buscar alertas ativos
  const { data: alerts, isLoading: alertsLoading } = trpc.alerts.getActive.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Buscar relatos recentes
  const { data: recentReports, isLoading: reportsLoading } = trpc.reports.getRecent.useQuery(
    { days: 7, limit: 10 },
    { enabled: isAuthenticated }
  );

  useEffect(() => {
    if (profile?.userType) {
      setUserType(profile.userType);
      setShowProfileModal(false);
    } else if (isAuthenticated && profile && !profile.userType) {
      setShowProfileModal(true);
    }
  }, [profile?.userType, isAuthenticated, profile]);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const calculateAggregateScore = () => {
    if (!roads || roads.length === 0) return 0;
    const total = roads.reduce((sum, road) => sum + road.agroScore, 0);
    return Math.round(total / roads.length);
  };

  const getStatusStats = () => {
    if (!roads) return { green: 0, yellow: 0, red: 0 };
    return {
      green: roads.filter(r => r.status === 'green').length,
      yellow: roads.filter(r => r.status === 'yellow').length,
      red: roads.filter(r => r.status === 'red').length
    };
  };

  const stats = getStatusStats();
  const aggregateScore = calculateAggregateScore();
  const totalKm = roads?.reduce((sum, road) => sum + road.totalKm, 0) || 0;

  if (!isAuthenticated) {
    return <div className="min-h-screen bg-gray-50" />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {showProfileModal && (
        <ProfileSelectionModal
          isOpen={showProfileModal}
          onClose={(type) => {
            if (type) {
              setUserType(type);
            }
            setShowProfileModal(false);
          }}
        />
      )}
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <p className="font-medium">{user?.name || "Usuário"}</p>
              <p className="text-gray-500 text-xs capitalize">{userType || "Carregando..."}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 flex gap-6">
          <Button variant="ghost" onClick={() => setLocation("/dashboard")}>
            Dashboard
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/map")}>
            <MapPin className="w-4 h-4 mr-2" />
            Mapa
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/reports")}>
            <AlertTriangle className="w-4 h-4 mr-2" />
            Relatos
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/about")}>
            Sobre
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h2>
          <p className="text-gray-600">Visão geral da trafegabilidade das estradas vicinais</p>
        </div>

        {/* KPI Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {/* AgroScore Agregado */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">AgroScore Geral</p>
                {roadsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-3xl font-bold text-green-600">{aggregateScore}</p>
                )}
              </div>
              <TrendingUp className="w-8 h-8 text-green-600 opacity-20" />
            </div>
          </Card>

          {/* Trafegável */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Trafegável</p>
                {roadsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-3xl font-bold text-green-600">{stats.green}</p>
                )}
              </div>
              <div className="w-3 h-3 rounded-full bg-green-600" />
            </div>
          </Card>

          {/* Atenção */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Atenção</p>
                {roadsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-3xl font-bold text-yellow-600">{stats.yellow}</p>
                )}
              </div>
              <div className="w-3 h-3 rounded-full bg-yellow-600" />
            </div>
          </Card>

          {/* Intransitável */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Intransitável</p>
                {roadsLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-3xl font-bold text-red-600">{stats.red}</p>
                )}
              </div>
              <div className="w-3 h-3 rounded-full bg-red-600" />
            </div>
          </Card>
        </div>

        {/* Total KM */}
        <Card className="p-6 mb-8">
          <p className="text-sm text-gray-600 mb-2">Total de Km Monitorados</p>
          <p className="text-4xl font-bold text-blue-600">{totalKm} km</p>
        </Card>

        {/* Estradas */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Estradas Listagem */}
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4">Estradas Vicinais</h3>
            {roadsLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {roads?.map((road) => (
                  <div
                    key={road.id}
                    className="flex items-center justify-between p-3 rounded border border-gray-200 hover:bg-gray-50"
                  >
                    <div className="flex-1">
                      <p className="font-medium">{road.name}</p>
                      <p className="text-xs text-gray-500">{road.totalKm} km</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: road.statusColor }}
                      />
                      <span className="text-sm font-bold text-gray-900 w-12 text-right">
                        {road.agroScore}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Alertas */}
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4">Alertas Ativos</h3>
            {alertsLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
              </div>
            ) : alerts && alerts.length > 0 ? (
              <div className="space-y-2">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="p-3 rounded border-l-4 border-red-500 bg-red-50"
                  >
                    <p className="font-medium text-sm">Estrada ID: {alert.roadId}</p>
                    <p className="text-xs text-gray-600">{alert.reason}</p>
                    <p className="text-xs text-red-600 mt-1">
                      Risco: {alert.riskLevel.toUpperCase()}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">Nenhum alerta ativo no momento</p>
            )}
          </Card>
        </div>

        {/* Relatos Recentes */}
        <Card className="p-6 mt-8">
          <h3 className="text-lg font-bold mb-4">Relatos Recentes (Últimos 7 dias)</h3>
          {reportsLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-10" />
              <Skeleton className="h-10" />
            </div>
          ) : recentReports && recentReports.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Tipo</th>
                    <th className="text-left py-2">Severidade</th>
                    <th className="text-left py-2">Status</th>
                    <th className="text-left py-2">Data</th>
                  </tr>
                </thead>
                <tbody>
                  {recentReports.map((report) => (
                    <tr key={report.id} className="border-b hover:bg-gray-50">
                      <td className="py-2 capitalize">{report.reportType}</td>
                      <td className="py-2">
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            report.severity === 'high'
                              ? 'bg-red-100 text-red-800'
                              : report.severity === 'medium'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-green-100 text-green-800'
                          }`}
                        >
                          {(report.severity || 'medium').toUpperCase()}
                        </span>
                      </td>
                      <td className="py-2 capitalize">{report.status}</td>
                      <td className="py-2 text-gray-500">
                        {new Date(report.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500 text-sm">Nenhum relato nos últimos 7 dias</p>
          )}
        </Card>
      </main>
    </div>
  );
}
