import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Leaf, MapPin, AlertTriangle, TrendingUp } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (isAuthenticated && user) {
    // Redirecionar para dashboard se autenticado
    setLocation("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="border-b border-green-100 bg-white">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota Inteligente</h1>
          </div>
          <nav className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation("/roads")}>
              Consultar Trafegabilidade
            </Button>
            <Button variant="ghost" onClick={() => setLocation("/about")}>
              Sobre
            </Button>
            <Button onClick={() => window.location.href = getLoginUrl()}>
              Entrar
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Monitoramento Inteligente de Estradas Rurais
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Acompanhe a trafegabilidade das estradas vicinais de Ariquemes em tempo real. 
            Relatos comunitários, alertas preditivos e dados transparentes para produtores, 
            motoristas e gestores públicos.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" onClick={() => window.location.href = getLoginUrl()}>
              Começar Agora
            </Button>
            <Button size="lg" variant="outline" onClick={() => setLocation("/roads")}>
              Consultar Status
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">Funcionalidades</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <div className="p-6 rounded-lg border border-green-100 bg-green-50">
              <TrendingUp className="w-8 h-8 text-green-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">AgroScore</h4>
              <p className="text-sm text-gray-600">
                Score de condição de cada estrada baseado em relatos e dados climáticos
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-lg border border-blue-100 bg-blue-50">
              <MapPin className="w-8 h-8 text-blue-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Mapa Interativo</h4>
              <p className="text-sm text-gray-600">
                Visualize todas as estradas vicinais com status de trafegabilidade em tempo real
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-lg border border-orange-100 bg-orange-50">
              <AlertTriangle className="w-8 h-8 text-orange-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Alertas Preditivos</h4>
              <p className="text-sm text-gray-600">
                Receba alertas antecipados baseados em previsão de chuva e histórico
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-lg border border-purple-100 bg-purple-50">
              <Leaf className="w-8 h-8 text-purple-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">Relatos Comunitários</h4>
              <p className="text-sm text-gray-600">
                Registre ocorrências com foto e localização para ajudar a comunidade
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4">Pronto para começar?</h3>
          <p className="text-lg mb-8 opacity-90">
            Faça login para acessar o dashboard completo e registrar relatos
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => window.location.href = getLoginUrl()}
          >
            Entrar Agora
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2026 AgroRota Inteligente. Desenvolvido para Ariquemes/RO</p>
        </div>
      </footer>
    </div>
  );
}
