import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MapView } from "@/components/Map";
import { Leaf, LogOut, AlertTriangle } from "lucide-react";
import { useEffect, useState } from "react";

export default function MapPage() {
  const { user, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedRoad, setSelectedRoad] = useState<any>(null);

  // Redirecionar se não autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  // Buscar estradas com scores
  const { data: roads, isLoading: roadsLoading } = trpc.roads.listWithScores.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Buscar relatos recentes
  const { data: recentReports, isLoading: reportsLoading } = trpc.reports.getRecent.useQuery(
    { days: 7, limit: 100 },
    { enabled: isAuthenticated }
  );

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <p className="font-medium">{user?.name || "Usuário"}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 flex gap-6">
          <Button variant="ghost" onClick={() => setLocation("/dashboard")}>
            Dashboard
          </Button>
          <Button variant="ghost" className="border-b-2 border-green-600">
            Mapa
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/reports")}>
            <AlertTriangle className="w-4 h-4 mr-2" />
            Relatos
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/about")}>
            Sobre
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Mapa de Trafegabilidade</h2>
          <p className="text-gray-600">
            Visualize as estradas vicinais com status de trafegabilidade em tempo real
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-4">
          {/* Map */}
          <div className="lg:col-span-3">
            <Card className="p-4 h-96">
              {roadsLoading ? (
                <Skeleton className="w-full h-full" />
              ) : (
                <MapView
                  initialCenter={{ lat: -9.9033, lng: -63.9031 }}
                  initialZoom={12}
                  onMapReady={(map: google.maps.Map) => {
                    // Centralizar no Ariquemes
                    map.setCenter({ lat: -9.9033, lng: -63.9031 });
                    map.setZoom(12);

                    // Adicionar marcadores das estradas
                    roads?.forEach((road) => {
                      const marker = new window.google.maps.Marker({
                        position: { lat: -9.9033, lng: -63.9031 },
                        map,
                        title: road.name,
                        icon: {
                          path: window.google.maps.SymbolPath.CIRCLE,
                          scale: 8,
                          fillColor: road.statusColor,
                          fillOpacity: 1,
                          strokeColor: "#fff",
                          strokeWeight: 2,
                        },
                      });

                      marker.addListener("click", () => {
                        setSelectedRoad(road);
                      });
                    });
                  }}
                />
              )}
            </Card>

            {/* Legend */}
            <Card className="p-4 mt-4">
              <h3 className="font-bold mb-3">Legenda</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-600" />
                  <span className="text-sm">Trafegável (AgroScore ≥ 70)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-yellow-600" />
                  <span className="text-sm">Atenção (40 ≤ AgroScore &lt; 70)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-600" />
                  <span className="text-sm">Intransitável (AgroScore &lt; 40)</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div>
            {/* Selected Road */}
            {selectedRoad ? (
              <Card className="p-4 mb-4">
                <h3 className="font-bold text-lg mb-3">{selectedRoad.name}</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-gray-600">AgroScore</p>
                    <p className="font-bold text-lg" style={{ color: selectedRoad.statusColor }}>
                      {selectedRoad.agroScore}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-600">Status</p>
                    <p className="font-medium">{selectedRoad.statusDescription}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Extensão</p>
                    <p className="font-medium">{selectedRoad.totalKm} km</p>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="p-4 mb-4 text-center text-gray-500">
                <p className="text-sm">Clique em um marcador para ver detalhes</p>
              </Card>
            )}

            {/* Relatos Próximos */}
            <Card className="p-4">
              <h3 className="font-bold mb-3">Relatos Recentes</h3>
              {reportsLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-10" />
                  <Skeleton className="h-10" />
                </div>
              ) : recentReports && recentReports.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {recentReports.slice(0, 5).map((report) => (
                    <div
                      key={report.id}
                      className="p-2 rounded border border-gray-200 text-xs"
                    >
                      <p className="font-medium capitalize">{report.reportType}</p>
                      <p className="text-gray-600 text-xs">
                        {new Date(report.createdAt).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-gray-500">Nenhum relato recente</p>
              )}
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
