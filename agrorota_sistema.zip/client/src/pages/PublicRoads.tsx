import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Leaf, Search } from "lucide-react";
import { useState } from "react";

export default function PublicRoads() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  // Buscar todas as estradas com scores
  const { data: roads, isLoading } = trpc.roads.listWithScores.useQuery();

  // Filtrar estradas baseado no termo de busca
  const filteredRoads = roads?.filter(
    (road) =>
      road.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      road.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota Inteligente</h1>
          </div>
          <nav className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation("/")}>
              Início
            </Button>
            <Button variant="ghost" onClick={() => setLocation("/about")}>
              Sobre
            </Button>
            <Button onClick={() => setLocation("/")}>
              Entrar
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Consultar Trafegabilidade
          </h2>
          <p className="text-gray-600">
            Verifique o status de trafegabilidade das estradas vicinais de Ariquemes
          </p>
        </div>

        {/* Search Box */}
        <Card className="p-6 mb-8">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Buscar por nome da linha (ex: C-70, B-40)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </Card>

        {/* Legend */}
        <div className="flex gap-6 mb-8 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-green-600" />
            <span className="text-sm font-medium">Trafegável (AgroScore ≥ 70)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-yellow-600" />
            <span className="text-sm font-medium">Atenção (40 ≤ AgroScore &lt; 70)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-red-600" />
            <span className="text-sm font-medium">Intransitável (AgroScore &lt; 40)</span>
          </div>
        </div>

        {/* Roads Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-40" />
            ))}
          </div>
        ) : filteredRoads && filteredRoads.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRoads.map((road) => (
              <Card
                key={road.id}
                className="p-6 hover:shadow-lg transition-shadow cursor-pointer border-l-4"
                style={{ borderLeftColor: road.statusColor }}
              >
                <div className="mb-4">
                  <h3 className="text-xl font-bold text-gray-900">{road.name}</h3>
                  {road.description && (
                    <p className="text-sm text-gray-600 mt-1">{road.description}</p>
                  )}
                </div>

                <div className="space-y-3">
                  {/* AgroScore */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">AgroScore</span>
                    <span
                      className="text-2xl font-bold"
                      style={{ color: road.statusColor }}
                    >
                      {road.agroScore}
                    </span>
                  </div>

                  {/* Status */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Status</span>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: road.statusColor }}
                      />
                      <span className="text-sm font-medium">
                        {road.statusDescription}
                      </span>
                    </div>
                  </div>

                  {/* Extensão */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Extensão</span>
                    <span className="text-sm font-medium">{road.totalKm} km</span>
                  </div>
                </div>

                {/* Details Button */}
                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => setLocation(`/roads/${road.id}`)}
                >
                  Ver Detalhes
                </Button>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-gray-600 mb-4">
              {searchTerm
                ? "Nenhuma estrada encontrada com esse termo"
                : "Nenhuma estrada disponível no momento"}
            </p>
            {searchTerm && (
              <Button variant="outline" onClick={() => setSearchTerm("")}>
                Limpar Busca
              </Button>
            )}
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2026 AgroRota Inteligente. Desenvolvido para Ariquemes/RO</p>
        </div>
      </footer>
    </div>
  );
}
