import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Leaf, LogOut, AlertTriangle, Upload } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function ReportsPage() {
  const { user, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    roadId: "",
    latitude: "",
    longitude: "",
    reportType: "pothole" as const,
    description: "",
    severity: "medium" as const,
  });
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Redirecionar se não autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  // Buscar estradas
  const { data: roads, isLoading: roadsLoading } = trpc.roads.list.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Buscar relatos do usuário
  const { data: userReports, isLoading: reportsLoading, refetch: refetchReports } = trpc.reports.getByUser.useQuery(
    { days: 30, limit: 50 },
    { enabled: isAuthenticated }
  );

  // Mutation para criar relato
  const createReportMutation = trpc.reports.create.useMutation({
    onSuccess: () => {
      toast.success("Relato registrado com sucesso!");
      setFormData({
        roadId: "",
        latitude: "",
        longitude: "",
        reportType: "pothole",
        description: "",
        severity: "medium",
      });
      setPhotoFile(null);
      refetchReports();
    },
    onError: (error) => {
      toast.error(`Erro ao registrar relato: ${error.message}`);
    },
  });

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setPhotoFile(e.target.files[0]);
    }
  };

  const handleGeolocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData({
            ...formData,
            latitude: position.coords.latitude.toString(),
            longitude: position.coords.longitude.toString(),
          });
          toast.success("Localização obtida com sucesso!");
        },
        (error) => {
          toast.error(`Erro ao obter localização: ${error.message}`);
        }
      );
    } else {
      toast.error("Geolocalização não suportada pelo navegador");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let photoUrl: string | undefined;

      // Upload da foto se fornecida
      if (photoFile) {
        const formDataPhoto = new FormData();
        formDataPhoto.append("file", photoFile);
        
        // Aqui você faria upload para S3 via endpoint
        // Por enquanto, vamos usar um mock
        photoUrl = `/photos/${photoFile.name}`;
      }

      // Criar relato
      await createReportMutation.mutateAsync({
        roadId: parseInt(formData.roadId),
        latitude: formData.latitude,
        longitude: formData.longitude,
        reportType: formData.reportType,
        description: formData.description,
        photoUrl,
        severity: formData.severity,
      });
    } catch (error) {
      console.error("Erro ao submeter relato:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-700">AgroRota</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <p className="font-medium">{user?.name || "Usuário"}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 flex gap-6">
          <Button variant="ghost" onClick={() => setLocation("/dashboard")}>
            Dashboard
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/map")}>
            Mapa
          </Button>
          <Button variant="ghost" className="border-b-2 border-green-600">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Relatos
          </Button>
          <Button variant="ghost" onClick={() => setLocation("/about")}>
            Sobre
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Registrar Relato</h2>
          <p className="text-gray-600">
            Ajude a comunidade informando sobre problemas nas estradas vicinais
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Estrada */}
                <div>
                  <label className="block text-sm font-medium mb-2">Estrada Vicinal *</label>
                  <select
                    value={formData.roadId}
                    onChange={(e) => setFormData({ ...formData, roadId: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="">Selecione uma estrada</option>
                    {roads?.map((road) => (
                      <option key={road.id} value={road.id}>
                        {road.name} ({road.totalKm} km)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Localização */}
                <div>
                  <label className="block text-sm font-medium mb-2">Localização *</label>
                  <div className="grid grid-cols-2 gap-4 mb-2">
                    <Input
                      type="number"
                      placeholder="Latitude"
                      value={formData.latitude}
                      onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                      step="0.0001"
                      required
                    />
                    <Input
                      type="number"
                      placeholder="Longitude"
                      value={formData.longitude}
                      onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                      step="0.0001"
                      required
                    />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleGeolocation}
                  >
                    Obter Localização Atual
                  </Button>
                </div>

                {/* Tipo de Ocorrência */}
                <div>
                  <label className="block text-sm font-medium mb-2">Tipo de Ocorrência *</label>
                  <select
                    value={formData.reportType}
                    onChange={(e) => setFormData({ ...formData, reportType: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="pothole">Buraco</option>
                    <option value="flooding">Alagamento</option>
                    <option value="mud">Lama</option>
                    <option value="landslide">Deslizamento</option>
                    <option value="other">Outro</option>
                  </select>
                </div>

                {/* Severidade */}
                <div>
                  <label className="block text-sm font-medium mb-2">Severidade</label>
                  <select
                    value={formData.severity}
                    onChange={(e) => setFormData({ ...formData, severity: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  >
                    <option value="low">Baixa</option>
                    <option value="medium">Média</option>
                    <option value="high">Alta</option>
                  </select>
                </div>

                {/* Descrição */}
                <div>
                  <label className="block text-sm font-medium mb-2">Descrição</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descreva o problema em detalhes..."
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>

                {/* Foto */}
                <div>
                  <label className="block text-sm font-medium mb-2">Foto (Opcional)</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                    {photoFile ? (
                      <div>
                        <p className="text-sm font-medium mb-2">{photoFile.name}</p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setPhotoFile(null)}
                        >
                          Remover
                        </Button>
                      </div>
                    ) : (
                      <label className="cursor-pointer">
                        <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                        <p className="text-sm text-gray-600">
                          Clique para selecionar uma foto
                        </p>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoChange}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>
                </div>

                {/* Submit */}
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting || !formData.roadId || !formData.latitude || !formData.longitude}
                >
                  {isSubmitting ? "Enviando..." : "Registrar Relato"}
                </Button>
              </form>
            </Card>
          </div>

          {/* Relatos Recentes */}
          <div>
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4">Seus Relatos</h3>
              {reportsLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-12" />
                  <Skeleton className="h-12" />
                </div>
              ) : userReports && userReports.length > 0 ? (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {userReports.map((report) => (
                    <div
                      key={report.id}
                      className="p-3 rounded border border-gray-200"
                    >
                      <p className="text-sm font-medium capitalize">{report.reportType}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(report.createdAt).toLocaleDateString('pt-BR')}
                      </p>
                      <div className="flex gap-1 mt-2">
                        <span
                          className={`text-xs px-2 py-1 rounded ${
                            report.severity === 'high'
                              ? 'bg-red-100 text-red-800'
                              : report.severity === 'medium'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-green-100 text-green-800'
                          }`}
                        >
                          {(report.severity || 'medium').toUpperCase()}
                        </span>
                        <span className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-800 capitalize">
                          {report.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Nenhum relato registrado</p>
              )}
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
