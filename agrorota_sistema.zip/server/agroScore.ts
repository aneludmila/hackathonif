import { getReportsByRoadId, getLatestAgroScore, createAgroScore } from "./db";

/**
 * AgroScore Calculation Engine
 * 
 * Calcula um score de 0-100 que representa a condição de trafegabilidade de uma estrada
 * baseado em relatos recentes, dados climáticos e tendência histórica.
 */

interface AgroScoreFactors {
  reportImpact: number;
  climateImpact: number;
  trendImpact: number;
  reportsCount: number;
  highSeverityCount: number;
}

/**
 * Calcula o impacto dos relatos recentes (últimos 7 dias)
 * Cada relato reduz o score dependendo da severidade
 */
async function calculateReportImpact(roadId: number): Promise<{ impact: number; count: number; highCount: number }> {
  const reports = await getReportsByRoadId(roadId, 100);
  
  // Filtrar relatos dos últimos 7 dias
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  
  const recentReports = reports.filter(r => new Date(r.createdAt) > sevenDaysAgo);
  
  let impact = 0;
  let highCount = 0;
  
  recentReports.forEach(report => {
    // Relatos resolvidos têm peso reduzido
    const weightMultiplier = report.status === 'resolved' ? 0.3 : 1;
    
    switch (report.severity) {
      case 'high':
        impact += 15 * weightMultiplier;
        highCount++;
        break;
      case 'medium':
        impact += 8 * weightMultiplier;
        break;
      case 'low':
        impact += 3 * weightMultiplier;
        break;
    }
  });
  
  return {
    impact: Math.min(impact, 60), // Máximo 60% de impacto
    count: recentReports.length,
    highCount
  };
}

/**
 * Calcula o impacto dos dados climáticos
 * Simula previsão de chuva (em produção, seria integrado com API real)
 */
function calculateClimateImpact(): { impact: number; reason: string } {
  // Mock: simular previsão de chuva
  // Em produção, isso viria de uma API como INMET ou OpenWeatherMap
  
  const now = new Date();
  const hour = now.getHours();
  
  // Simular padrão de chuva ao longo do dia
  let rainLevel = 'none';
  let impact = 0;
  
  if (hour >= 10 && hour <= 16) {
    // Período de maior chance de chuva (simulado)
    rainLevel = 'moderate';
    impact = 15;
  } else if (hour >= 16 && hour <= 20) {
    rainLevel = 'heavy';
    impact = 30;
  }
  
  return {
    impact: Math.min(impact, 30), // Máximo 30% de impacto
    reason: `Previsão de chuva: ${rainLevel}`
  };
}

/**
 * Calcula o impacto da tendência histórica
 * Verifica se o score vinha melhorando ou piorando
 */
async function calculateTrendImpact(roadId: number): Promise<{ impact: number; trend: string }> {
  const history = await getLatestAgroScore(roadId);
  
  if (!history) {
    return { impact: 0, trend: 'sem histórico' };
  }
  
  // Simular tendência (em produção, comparar com scores anteriores)
  // Para MVP, retornar impacto neutro
  return {
    impact: 0,
    trend: 'estável'
  };
}

/**
 * Calcula o AgroScore final
 * Fórmula: 100 - (relatos * 0.6) - (clima * 0.3) - (tendência * 0.1)
 */
export async function calculateAgroScore(roadId: number): Promise<{
  score: number;
  factors: AgroScoreFactors;
  status: 'green' | 'yellow' | 'red';
}> {
  const reportResult = await calculateReportImpact(roadId);
  const climateResult = calculateClimateImpact();
  const trendResult = await calculateTrendImpact(roadId);
  
  const factors: AgroScoreFactors = {
    reportImpact: reportResult.impact,
    climateImpact: climateResult.impact,
    trendImpact: trendResult.impact,
    reportsCount: reportResult.count,
    highSeverityCount: reportResult.highCount
  };
  
  // Fórmula ponderada
  const score = Math.max(
    0,
    Math.min(
      100,
      100 - (factors.reportImpact * 0.6) - (factors.climateImpact * 0.3) - (factors.trendImpact * 0.1)
    )
  );
  
  // Determinar status baseado no score
  let status: 'green' | 'yellow' | 'red';
  if (score >= 70) {
    status = 'green';
  } else if (score >= 40) {
    status = 'yellow';
  } else {
    status = 'red';
  }
  
  // Salvar no histórico
  await createAgroScore({
    roadId,
    score: Math.round(score),
    factors: JSON.stringify(factors)
  });
  
  return {
    score: Math.round(score),
    factors,
    status
  };
}

/**
 * Retorna a descrição do status de trafegabilidade
 */
export function getStatusDescription(status: 'green' | 'yellow' | 'red'): string {
  switch (status) {
    case 'green':
      return 'Trafegável';
    case 'yellow':
      return 'Atenção';
    case 'red':
      return 'Intransitável';
  }
}

/**
 * Retorna a cor hexadecimal para o status
 */
export function getStatusColor(status: 'green' | 'yellow' | 'red'): string {
  switch (status) {
    case 'green':
      return '#22c55e';
    case 'yellow':
      return '#eab308';
    case 'red':
      return '#ef4444';
  }
}
