import { eq, desc, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, roads, reports, alerts, agroScores, userProfiles, type Road, type Report, type Alert, type AgroScore, type UserProfile } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== ROADS =====

export async function getAllRoads(): Promise<Road[]> {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(roads);
}

export async function getRoadById(roadId: number): Promise<Road | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(roads).where(eq(roads.id, roadId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createRoad(data: { name: string; description?: string; totalKm: number; coordinates?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(roads).values(data);
  return result;
}

// ===== REPORTS =====

export async function getReportsByRoadId(roadId: number, limit: number = 50): Promise<Report[]> {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(reports)
    .where(eq(reports.roadId, roadId))
    .orderBy(desc(reports.createdAt))
    .limit(limit);
}

export async function getRecentReports(days: number = 7, limit: number = 100): Promise<Report[]> {
  const db = await getDb();
  if (!db) return [];
  const sinceDate = new Date();
  sinceDate.setDate(sinceDate.getDate() - days);
  
  return await db
    .select()
    .from(reports)
    .where(gte(reports.createdAt, sinceDate))
    .orderBy(desc(reports.createdAt))
    .limit(limit);
}

export async function getReportsByUserId(userId: number, days: number = 30, limit: number = 50): Promise<Report[]> {
  const db = await getDb();
  if (!db) return [];
  const sinceDate = new Date();
  sinceDate.setDate(sinceDate.getDate() - days);
  
  return await db
    .select()
    .from(reports)
    .where(and(eq(reports.userId, userId), gte(reports.createdAt, sinceDate)))
    .orderBy(desc(reports.createdAt))
    .limit(limit);
}

export async function createReport(data: {
  roadId: number;
  userId: number;
  latitude: string;
  longitude: string;
  reportType: 'pothole' | 'flooding' | 'mud' | 'landslide' | 'other';
  description?: string;
  photoUrl?: string;
  severity: 'low' | 'medium' | 'high';
}): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(reports).values(data);
}

export async function updateReportStatus(reportId: number, status: 'open' | 'acknowledged' | 'resolved'): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(reports).set({ status }).where(eq(reports.id, reportId));
}

// ===== ALERTS =====

export async function getActiveAlerts(): Promise<Alert[]> {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(alerts)
    .where(and(eq(alerts.isActive, 1), gte(alerts.expiresAt, new Date())))
    .orderBy(desc(alerts.createdAt));
}

export async function getAlertsByRoadId(roadId: number): Promise<Alert[]> {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(alerts)
    .where(eq(alerts.roadId, roadId))
    .orderBy(desc(alerts.createdAt));
}

export async function createAlert(data: {
  roadId: number;
  riskLevel: 'low' | 'medium' | 'high';
  reason?: string;
  predictedDate?: string;
  expiresAt?: Date;
}): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(alerts).values(data);
}

// ===== AGRO SCORES =====

export async function getLatestAgroScore(roadId: number): Promise<AgroScore | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(agroScores)
    .where(eq(agroScores.roadId, roadId))
    .orderBy(desc(agroScores.calculatedAt))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createAgroScore(data: {
  roadId: number;
  score: number;
  factors?: string;
}): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(agroScores).values(data);
}

export async function getAgroScoreHistory(roadId: number, limit: number = 30): Promise<AgroScore[]> {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(agroScores)
    .where(eq(agroScores.roadId, roadId))
    .orderBy(desc(agroScores.calculatedAt))
    .limit(limit);
}

// ===== USER PROFILES =====

export async function getUserProfile(userId: number): Promise<UserProfile | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(userProfiles)
    .where(eq(userProfiles.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateUserProfile(userId: number, userType: 'producer' | 'manager' | 'viewer'): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getUserProfile(userId);
  if (existing) {
    await db.update(userProfiles).set({ userType }).where(eq(userProfiles.userId, userId));
  } else {
    await db.insert(userProfiles).values({ userId, userType });
  }
}
