import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { calculateAgroScore, getStatusDescription, getStatusColor } from "./agroScore";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  roads: router({
    list: publicProcedure.query(async () => {
      return await db.getAllRoads();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getRoadById(input.id);
      }),
    
    getWithScore: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const road = await db.getRoadById(input.id);
        if (!road) return null;
        
        const scoreResult = await calculateAgroScore(input.id);
        return {
          ...road,
          agroScore: scoreResult.score,
          status: scoreResult.status,
          statusDescription: getStatusDescription(scoreResult.status),
          statusColor: getStatusColor(scoreResult.status)
        };
      }),
    
    listWithScores: publicProcedure.query(async () => {
      const roads = await db.getAllRoads();
      const roadsWithScores = await Promise.all(
        roads.map(async (road) => {
          const scoreResult = await calculateAgroScore(road.id);
          return {
            ...road,
            agroScore: scoreResult.score,
            status: scoreResult.status,
            statusDescription: getStatusDescription(scoreResult.status),
            statusColor: getStatusColor(scoreResult.status)
          };
        })
      );
      return roadsWithScores;
    })
  }),

  reports: router({
    getByRoad: publicProcedure
      .input(z.object({ roadId: z.number(), limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return await db.getReportsByRoadId(input.roadId, input.limit);
      }),
    
    getRecent: publicProcedure
      .input(z.object({ days: z.number().default(7), limit: z.number().default(100) }))
      .query(async ({ input }) => {
        return await db.getRecentReports(input.days, input.limit);
      }),
    
    getByUser: protectedProcedure
      .input(z.object({ days: z.number().default(30), limit: z.number().default(50) }))
      .query(async ({ input, ctx }) => {
        return await db.getReportsByUserId(ctx.user!.id, input.days, input.limit);
      }),
    
    create: protectedProcedure
      .input(z.object({
        roadId: z.number(),
        latitude: z.string(),
        longitude: z.string(),
        reportType: z.enum(['pothole', 'flooding', 'mud', 'landslide', 'other']),
        description: z.string().optional(),
        photoUrl: z.string().optional(),
        severity: z.enum(['low', 'medium', 'high']).default('medium')
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await db.createReport({
          ...input,
          userId: ctx.user!.id
        });
        
        // Recalcular AgroScore da estrada
        await calculateAgroScore(input.roadId);
        
        return result;
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        reportId: z.number(),
        status: z.enum(['open', 'acknowledged', 'resolved'])
      }))
      .mutation(async ({ input, ctx }) => {
        // Apenas gestores podem atualizar status
        const userProfile = await db.getUserProfile(ctx.user!.id);
        if (userProfile?.userType !== 'manager') {
          throw new Error('Apenas gestores podem atualizar o status de relatos');
        }
        
        await db.updateReportStatus(input.reportId, input.status);
        return { success: true };
      })
  }),

  alerts: router({
    getActive: publicProcedure.query(async () => {
      return await db.getActiveAlerts();
    }),
    
    getByRoad: publicProcedure
      .input(z.object({ roadId: z.number() }))
      .query(async ({ input }) => {
        return await db.getAlertsByRoadId(input.roadId);
      })
  }),

  userProfile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const profile = await db.getUserProfile(ctx.user!.id);
      return profile || { userId: ctx.user!.id, userType: null, createdAt: new Date(), updatedAt: new Date() };
    }),
    
    set: protectedProcedure
      .input(z.object({ userType: z.enum(['producer', 'manager', 'viewer']) }))
      .mutation(async ({ input, ctx }) => {
        await db.createOrUpdateUserProfile(ctx.user!.id, input.userType);
        return { success: true };
      })
  })
});

export type AppRouter = typeof appRouter;
