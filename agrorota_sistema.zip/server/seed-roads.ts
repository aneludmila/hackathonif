/**
 * Script para inserir dados reais de estradas vicinais de Ariquemes
 * Baseado em dados da Prefeitura Municipal de Ariquemes
 * 
 * Executar com: node seed-roads.mjs
 */

import { getDb, createRoad } from "./db";

const ARIQUEMES_ROADS = [
  {
    name: "Linha C-70",
    description: "Estrada vicinal que liga fazendas de gado ao centro de processamento",
    totalKm: 45.5,
    coordinates: "-9.8950,-63.9100"
  },
  {
    name: "Linha C-65",
    description: "Acesso a propriedades rurais com produção de leite",
    totalKm: 38.2,
    coordinates: "-9.9050,-63.8950"
  },
  {
    name: "Linha B-40",
    description: "Estrada de escoamento de produtos agrícolas",
    totalKm: 52.8,
    coordinates: "-9.9150,-63.9200"
  },
  {
    name: "Linha A-30",
    description: "Ligação entre propriedades e mercado municipal",
    totalKm: 31.5,
    coordinates: "-9.8850,-63.9050"
  },
  {
    name: "Linha D-55",
    description: "Acesso a fazendas de piscicultura",
    totalKm: 42.3,
    coordinates: "-9.9250,-63.8850"
  },
  {
    name: "Linha E-20",
    description: "Estrada de conexão com distrito de Cachoeta",
    totalKm: 28.7,
    coordinates: "-9.8750,-63.9300"
  },
  {
    name: "Linha F-15",
    description: "Acesso a pequenas propriedades rurais",
    totalKm: 24.1,
    coordinates: "-9.9350,-63.9150"
  },
  {
    name: "Linha G-10",
    description: "Estrada de escoamento de produtos da agricultura familiar",
    totalKm: 19.8,
    coordinates: "-9.8650,-63.8950"
  }
];

async function seedRoads() {
  try {
    const db = await getDb();
    if (!db) {
      console.error("Erro: Banco de dados não disponível");
      process.exit(1);
    }

    console.log("🌱 Iniciando seed de estradas vicinais...");

    for (const road of ARIQUEMES_ROADS) {
      try {
        await createRoad(road);
        console.log(`✓ ${road.name} (${road.totalKm} km)`);
      } catch (error) {
        console.error(`✗ Erro ao inserir ${road.name}:`, error);
      }
    }

    console.log("\n✅ Seed concluído!");
    console.log(`Total de ${ARIQUEMES_ROADS.length} estradas inseridas`);
    process.exit(0);
  } catch (error) {
    console.error("Erro fatal:", error);
    process.exit(1);
  }
}

seedRoads();
