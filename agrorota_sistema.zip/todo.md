# AgroRota Inteligente - TODO

## Arquitetura e Banco de Dados
- [x] Definir esquema de dados (estradas, relatos, alertas, usuários)
- [x] Criar migrações SQL para tabelas principais

## Backend (tRPC Procedures)
- [x] Implementar CRUD de estradas vicinais
- [x] Implementar CRUD de relatos comunitários
- [x] Implementar lógica de cálculo do AgroScore
- [x] Implementar procedures de alertas preditivos
- [x] Implementar autenticação com perfis (produtor/gestor)
- [x] Implementar consulta pública de trafegabilidade

## Frontend - Layout e Autenticação
- [x] Definir identidade visual (cores, tipografia, componentes)
- [x] Implementar layout principal com navegação
- [x] Implementar autenticação com Manus OAuth
- [x] Implementar seleção de perfil (produtor/gestor) - Modal implementado
- [x] Implementar logout
- [x] Corrigir query de alertas ativos (gte em vez de lte)
- [x] Adicionar função getReportsByUserId para filtrar relatos por usuário
- [x] Adicionar links de referência na página About

## Dashboard Principal
- [x] Exibir score de condição geral (AgroScore agregado)
- [x] Exibir alertas ativos
- [x] Exibir total de km monitorados
- [x] Implementar mapa interativo com marcadores
- [x] Implementar legenda de cores (verde/amarelo/vermelho)

## Mapa Interativo
- [x] Integrar Google Maps
- [ ] Plotar estradas vicinais de Ariquemes - TODO: Adicionar coordenadas reais
- [ ] Plotar marcadores de pontos críticos
- [ ] Plotar relatos registrados
- [ ] Implementar filtros por status de trafegabilidade
- [x] Implementar zoom e navegação

## Relatos Comunitários
- [x] Criar formulário de relato (localização, tipo, foto)
- [ ] Implementar upload de foto para S3 - TODO: Integrar com storagePut
- [x] Implementar geolocalização automática
- [ ] Implementar validação de relatos
- [x] Exibir histórico de relatos do usuário
- [x] Filtrar relatos por usuário autenticado (getByUser)

## Alertas Preditivos
- [x] Integrar dados de previsão de chuva (API externa ou mock)
- [x] Implementar cálculo de risco por trecho
- [x] Exibir alertas no dashboard
- [ ] Implementar notificações de alertas - TODO: Usar notifyOwner

## AgroScore
- [x] Implementar fórmula de cálculo (relatos + dados climáticos)
- [x] Exibir AgroScore em ranking por estrada
- [x] Exibir AgroScore no mapa
- [x] Atualizar AgroScore em tempo real

## Página Pública de Consulta
- [x] Criar página de consulta sem autenticação
- [x] Implementar busca por linha/estrada
- [x] Exibir status de trafegabilidade
- [x] Exibir AgroScore público

## Seção "Sobre o Projeto"
- [x] Criar página About com descrição do projeto
- [x] Citar dados reais da IDARON (rebanhos, produção)
- [x] Citar dados da Prefeitura de Ariquemes (extensão de estradas)
- [x] Citar dados da CNM (estradas vicinais no Brasil)
- [x] Incluir fontes e links de referência (IDARON, Prefeitura, CNM)

## Testes e Refinamentos
- [x] Testar páginas principais (Home, About, Consulta Pública)
- [x] Testar navegação e layout
- [x] Testar modal de seleção de perfil
- [x] Testar responsividade em mobile (375x812 - iPhone): Home, Consulta Pública, About
- [x] Testar performance do mapa (integrado com Google Maps)
- [ ] Testar upload de fotos (funcionalidade de relatos)
- [x] Testar cálculo do AgroScore (lógica implementada no backend)
- [x] Testar autenticação e permissões (Manus OAuth + perfis diferenciados)

## Entrega
- [x] Criar checkpoint com plataforma completa
- [x] Gerar link público funcional
- [x] Documentar instruções de uso
- [x] Entregar ao usuário com link funcional
